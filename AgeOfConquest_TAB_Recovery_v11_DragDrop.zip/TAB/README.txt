AGE OF CONQUEST TAB — REFINED v3

CHANGES
- Logo lowered significantly: ascent 3, height 26.
- Two spacer lines below the glyph prevent overlap.
- Full AGE OF CONQUEST logo should now fit instead of only CONQUEST.
- Maximum player display is fixed at 100.
- Scoreboard completely refined with cleaner kingdom, wealth and server sections.
- Animations slowed for a premium, readable presentation.

INSTALL
1. Stop the server.
2. Replace plugins/TAB with the TAB folder in this package.
3. Upload AgeOfConquest_TAB_Logo_ResourcePack.zip to GitHub, replacing the old file.
4. Change resource-pack-sha1 in server.properties to:
   6a744a536f8535d54ec1787cb7efb5bea204ac66
5. Start the server normally.
6. Reconnect so the client downloads the updated pack.

Do not use /reload.

AGE OF CONQUEST TAB v11

CHANGES
- Actual logo artwork reduced to 28x28 pixels.
- Font height set to 1.
- Font ascent set to 0.
- Logo positioned near the bottom of the texture.

INSTALL
1. Stop the server.
2. Replace plugins/TAB with the included TAB folder.
3. Upload AgeOfConquest_TAB_Logo_ResourcePack_v11.zip to GitHub.
4. Update server.properties:
   resource-pack-sha1=cc6f6b9590f1839005cf098b002d80a0c767a9a8
5. Delete the cached server pack from:
   .minecraft/server-resource-packs/
6. Start the server and reconnect.
